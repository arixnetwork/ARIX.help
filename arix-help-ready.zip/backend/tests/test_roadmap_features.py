import pytest
from fastapi.testclient import TestClient
from types import SimpleNamespace

import server


class FakeCollection:
    def __init__(self):
        self.docs = []

    async def insert_one(self, doc):
        self.docs.append(doc)
        return SimpleNamespace(inserted_id="ok")

    async def find_one(self, *args, **kwargs):
        return self.docs[0] if self.docs else None

    async def delete_many(self, *args, **kwargs):
        return SimpleNamespace(deleted_count=len(self.docs))


@pytest.fixture
def client(monkeypatch):
    db = SimpleNamespace(projects=FakeCollection(), project_files=FakeCollection())
    monkeypatch.setattr(server, "db", db)

    user = server.User(
        user_id="user_test_1",
        email="test@example.com",
        name="Test User",
        role="pro",
        auth_provider="password",
    )

    async def fake_user():
        return user

    server.app.dependency_overrides[server.get_current_user] = fake_user
    with TestClient(server.app) as c:
        yield c
    server.app.dependency_overrides.clear()


def test_runtime_status(client):
    r = client.get("/api/runtime/status")
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "healthy"
    assert "containers" in body


def test_github_import(client):
    r = client.post(
        "/api/github/import",
        json={"repo_url": "https://github.com/vercel/next.js", "project_name": "next-demo"},
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["source"] == "github"
    assert body["project_name"] == "next-demo"
    assert body["status"] == "ready"


def test_billing_usage(client):
    r = client.get("/api/billing/usage")
    assert r.status_code == 200
    body = r.json()
    assert body["plan"] in {"Free", "Pro", "Enterprise"}
    assert "limits" in body


def test_team_members(client):
    r = client.get("/api/team/members")
    assert r.status_code == 200
    body = r.json()
    assert isinstance(body, list)
    assert any(member["role"] == "Owner" for member in body)


def test_marketplace_catalog(client):
    r = client.get("/api/marketplace")
    assert r.status_code == 200
    body = r.json()
    assert isinstance(body, list)
    assert len(body) >= 3
